import { 
  int, 
  mysqlEnum, 
  mysqlTable, 
  text, 
  timestamp, 
  varchar,
  decimal,
  boolean,
  datetime
} from "drizzle-orm/mysql-core";

/**
 * جدول المستخدمين - للمدراء والموظفين
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * جدول الموظفين - بيانات الموظفين الأساسية
 */
export const employees = mysqlTable("employees", {
  id: int("id").autoincrement().primaryKey(),
  employeeNumber: varchar("employeeNumber", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  department: varchar("department", { length: 100 }).notNull(),
  position: varchar("position", { length: 100 }),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  hireDate: datetime("hireDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;

/**
 * جدول السجلات - تسجيلات الحضور والانصراف
 * المنطق: أي تسجيل بعد منتصف الليل (00:00) يُربط بالوردية السابقة
 */
export const attendanceRecords = mysqlTable("attendanceRecords", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  // تاريخ الوردية (يوم بدء الوردية)
  shiftDate: datetime("shiftDate").notNull(),
  // وقت التسجيل الفعلي
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
  // نوع التسجيل: دخول أو خروج
  type: mysqlEnum("type", ["checkin", "checkout"]).notNull(),
  // ملاحظات إضافية (مثل سبب التأخر)
  notes: text("notes"),
  // هل تم التحقق من السجل يدوياً
  isManualEntry: boolean("isManualEntry").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type InsertAttendanceRecord = typeof attendanceRecords.$inferInsert;

/**
 * جدول الورديات - تجميع السجلات لكل وردية
 * يتم حساب ساعات العمل تلقائياً من الفرق بين الدخول والخروج
 */
export const shifts = mysqlTable("shifts", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  // تاريخ بدء الوردية
  shiftDate: datetime("shiftDate").notNull(),
  // وقت الدخول
  checkInTime: timestamp("checkInTime"),
  // وقت الخروج
  checkOutTime: timestamp("checkOutTime"),
  // ساعات العمل (بالساعات العشرية)
  workHours: decimal("workHours", { precision: 5, scale: 2 }),
  // حالة الوردية
  status: mysqlEnum("status", ["incomplete", "complete"]).default("incomplete").notNull(),
  // ملاحظات
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Shift = typeof shifts.$inferSelect;
export type InsertShift = typeof shifts.$inferInsert;

/**
 * جدول الإحصائيات اليومية - لتسريع عرض التقارير
 */
export const dailyStatistics = mysqlTable("dailyStatistics", {
  id: int("id").autoincrement().primaryKey(),
  date: datetime("date").notNull(),
  totalEmployees: int("totalEmployees").notNull(),
  presentCount: int("presentCount").notNull(),
  absentCount: int("absentCount").notNull(),
  lateCount: int("lateCount").notNull(),
  earlyLeaveCount: int("earlyLeaveCount").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyStatistics = typeof dailyStatistics.$inferSelect;
export type InsertDailyStatistics = typeof dailyStatistics.$inferInsert;

/**
 * جدول سياسات الحضور - لتحديد أوقات العمل المتوقعة
 */
export const attendancePolicies = mysqlTable("attendancePolicies", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  expectedWorkHours: decimal("expectedWorkHours", { precision: 5, scale: 2 }).notNull(),
  lateThresholdMinutes: int("lateThresholdMinutes").default(15).notNull(),
  earlyLeaveThresholdMinutes: int("earlyLeaveThresholdMinutes").default(15).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AttendancePolicy = typeof attendancePolicies.$inferSelect;
export type InsertAttendancePolicy = typeof attendancePolicies.$inferInsert;
