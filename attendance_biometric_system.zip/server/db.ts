import { eq, and, gte, lte, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  employees,
  attendanceRecords,
  shifts,
  dailyStatistics,
  attendancePolicies,
  type Employee,
  type AttendanceRecord,
  type Shift,
  type InsertEmployee,
  type InsertAttendanceRecord,
  type InsertShift,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============= المستخدمون =============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============= الموظفون =============

export async function createEmployee(data: InsertEmployee) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(employees).values(data);
  return result;
}

export async function updateEmployee(id: number, data: Partial<InsertEmployee>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(employees).set(data).where(eq(employees.id, id));
}

export async function deleteEmployee(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(employees).where(eq(employees.id, id));
}

export async function getEmployeeById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(employees).where(eq(employees.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getEmployeeByNumber(employeeNumber: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(employees).where(eq(employees.employeeNumber, employeeNumber)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllEmployees() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(employees).where(eq(employees.status, "active"));
}

// ============= السجلات والورديات =============

/**
 * معالجة ذكية لتسجيل الحضور والانصراف
 * إذا كان الوقت بعد منتصف الليل، يتم ربطه بالوردية السابقة
 * إذا لم يتم تحديد type، يتم تحديده تلقائياً بناءاً على آخر سجل
 */
export async function recordAttendance(
  employeeId: number,
  typeOverride?: "checkin" | "checkout",
  isManualEntry: boolean = false,
  notes?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  
  // حساب تاريخ الوردية: إذا كان الوقت بعد منتصف الليل، استخدم تاريخ أمس
  const shiftDate = new Date(now);
  if (now.getHours() < 6) { // قبل الساعة 6 صباحاً
    shiftDate.setDate(shiftDate.getDate() - 1);
  }
  shiftDate.setHours(0, 0, 0, 0);
  
  // تحديد نوع التسجيل تلقائياً إذا لم يتم تحديده
  let type = typeOverride;
  if (!type) {
    // البحث عن آخر سجل للموظف في هذه الوردية
    const lastRecord = await db
      .select()
      .from(attendanceRecords)
      .where(
        and(
          eq(attendanceRecords.employeeId, employeeId),
          eq(sql`DATE(${attendanceRecords.shiftDate})`, sql`DATE(${shiftDate})`)
        )
      )
      .orderBy(desc(attendanceRecords.recordedAt))
      .limit(1);
    
    if (lastRecord.length > 0) {
      // إذا كان آخر سجل هو دخول، سجل خروج
      type = lastRecord[0].type === "checkin" ? "checkout" : "checkin";
    } else {
      // إذا لم يوجد سجل، سجل دخول
      type = "checkin";
    }
  }

  // إنشاء سجل الحضور
  const record: InsertAttendanceRecord = {
    employeeId,
    shiftDate,
    type: type as "checkin" | "checkout",
    isManualEntry,
    notes,
  };

  const recordResult = await db.insert(attendanceRecords).values(record);

  // تحديث أو إنشاء الوردية
  const existingShift = await db
    .select()
    .from(shifts)
    .where(and(
      eq(shifts.employeeId, employeeId),
      eq(shifts.shiftDate, shiftDate)
    ))
    .limit(1);

  if (existingShift.length > 0) {
    // تحديث الوردية الموجودة
    const shift = existingShift[0];
    const updateData: Partial<InsertShift> = {};

    if (type === "checkin" && !shift.checkInTime) {
      updateData.checkInTime = now;
    } else if (type === "checkout") {
      updateData.checkOutTime = now;
      updateData.status = "complete";

      // حساب ساعات العمل
      if (shift.checkInTime) {
        const checkIn = new Date(shift.checkInTime).getTime();
        const checkOut = now.getTime();
        const hours = (checkOut - checkIn) / (1000 * 60 * 60);
        updateData.workHours = hours.toFixed(2) as any;
      }
    }

    if (Object.keys(updateData).length > 0) {
      await db.update(shifts).set(updateData).where(eq(shifts.id, shift.id));
    }
  } else if (type === "checkin") {
    // إنشاء وردية جديدة
    const newShift: InsertShift = {
      employeeId,
      shiftDate,
      checkInTime: now,
      status: "incomplete",
    };
    await db.insert(shifts).values(newShift);
  }

  return recordResult;
}

export async function getEmployeeShifts(
  employeeId: number,
  startDate?: Date,
  endDate?: Date
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const conditions = [eq(shifts.employeeId, employeeId)];

  if (startDate && endDate) {
    conditions.push(
      gte(shifts.shiftDate, startDate),
      lte(shifts.shiftDate, endDate)
    );
  }

  return await db.select().from(shifts).where(and(...conditions)).orderBy(desc(shifts.shiftDate));
}

export async function getAttendanceRecords(
  employeeId: number,
  startDate?: Date,
  endDate?: Date
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const conditions = [eq(attendanceRecords.employeeId, employeeId)];

  if (startDate && endDate) {
    conditions.push(
      gte(attendanceRecords.shiftDate, startDate),
      lte(attendanceRecords.shiftDate, endDate)
    );
  }

  return await db.select().from(attendanceRecords).where(and(...conditions)).orderBy(desc(attendanceRecords.recordedAt));
}

// ============= الإحصائيات =============

export async function getDailyStatistics(date: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(dailyStatistics)
    .where(eq(dailyStatistics.date, date))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function calculateDailyStatistics(date: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const allEmployees = await db.select().from(employees).where(eq(employees.status, "active"));
  
  const shiftsForDate = await db
    .select()
    .from(shifts)
    .where(eq(sql`DATE(${shifts.shiftDate})`, sql`DATE(${date})`));

  const presentEmployeeIds = new Set(shiftsForDate.map(s => s.employeeId));
  
  const presentCount = presentEmployeeIds.size;
  const absentCount = allEmployees.length - presentCount;
  
  // حساب المتأخرين والمغادرين مبكراً (يمكن تحسينه لاحقاً)
  const lateCount = 0;
  const earlyLeaveCount = 0;

  const stats = {
    date,
    totalEmployees: allEmployees.length,
    presentCount,
    absentCount,
    lateCount,
    earlyLeaveCount,
  };

  // تحديث أو إنشاء الإحصائيات
  const existing = await getDailyStatistics(date);
  if (existing) {
    await db.update(dailyStatistics).set(stats).where(eq(dailyStatistics.id, existing.id));
  } else {
    await db.insert(dailyStatistics).values(stats);
  }

  return stats;
}
